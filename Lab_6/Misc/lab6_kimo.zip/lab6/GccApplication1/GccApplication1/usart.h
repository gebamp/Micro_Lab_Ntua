void usart_init(void)
{
    UCSRA = 0; //Initialize USCRA as 0
    // Activate transmitter receiver
    UCSRB = (1 << RXEN) | (1 << TXEN);
    //Baud rate = 9600
    UBRRH = 0;
    UBRRL = 51;
    // 8 bit character size 1 stop bit
    UCSRC = (1 << URSEL) | (3 << UCSZ0);
}

void usart_transmit(unsigned char byte)
{
    while (!(UCSRA & (1 << UDRE)));
    UDR = byte;
}
unsigned char usart_receive(void)
{
    while (!(UCSRA & (1 << RXC)));
    return UDR;
}

void usart_transmit_string(char *s)
{
	cli();
    for (char c = *s; c != '\0'; c = *++s)
        usart_transmit(c);

    usart_transmit(0x00);
	sei();
}


void usart_receive_string(char *buffer,char length)
{
    char i = 0;
	cli();
    while ((*(buffer+i) = usart_receive()) != '\0' && i<length);
	sei();
}