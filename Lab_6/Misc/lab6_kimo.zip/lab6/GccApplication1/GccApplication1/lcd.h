#define F_CPU 8000000UL
#include <util/delay.h>

void write_2_nibbles(char data)
{
	char previous_state = PIND;
	PORTD = (data&0xf0) | (previous_state&0x0f);
	
	PORTD |= (1<<PD3);
	PORTD &= ~(1<<PD3);
	
	PORTD = ((data&0x0f)<<4) | (previous_state&0x0f);
	
	PORTD |= (1<<PD3);
	PORTD &= ~(1<<PD3);
	
	return;
}

void lcd_data(char data)
{
	PORTD |= (1<<PD2);
	write_2_nibbles(data);
	
	_delay_us(43);
	
	return;
}


void lcd_command(char command)
{
	PORTD &= ~(1<<PD2);
	write_2_nibbles(command);
	
	_delay_us(39);
	
	return;
}


void lcd_init()
{
	_delay_ms(40);
	PORTD = 0x30;
	PORTD |= (1<<PD3);
	PORTD &= ~(1<<PD3);
	_delay_us(39);
	
	PORTD = 0x30;
	PORTD |= (1<<PD3);
	PORTD &= ~(1<<PD3);
	_delay_us(20);
	
	PORTD = 0x20;
	PORTD |= (1<<PD3);
	PORTD &= ~(1<<PD3);
	_delay_us(39);
	
	lcd_command(0x28);
	lcd_command(0x0c);
	lcd_command(0x01);
	
	_delay_us(1530);
	
	lcd_command(0x06);
	
	return;
}

void lcd_string(const char* s)
{
	char i=0;
	while( *(s+i) != '\0' )
	lcd_data(*(s+i));
}