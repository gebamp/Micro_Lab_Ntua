#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include "lcd.h"
#include "usart.h"
#include "DS1820.h"
#include "keypad.h"
#define F_CPU 8000000UL
#include <util/delay.h>

char res[3];
void get_digits(char number)
{
	char res[3];
	if(number>=100){
		res[2]++;
		number = number -100;
	}
	while(number >=10){
		res[1]++;
		number = number -10;
	}
	res[0] = number;
}

char compare_string(char *s1, char *s2)
{
	char i = 0;
	while (1)
	{
		if (*(s1 + i) != *(s2 + i))
		return 0;
		if (*(s1 + i) == *(s2 + i) && *(s1 + i) == '\0')
		return 1;
	}
}

char usart_buffer[8];
void check_success()
{
	usart_receive_string(usart_buffer,8);
	if (strcmp(usart_buffer,"Fail") == 0)
		lcd_string("3.Fail");
	else
		lcd_string("3.Success");
}

void initialize_team_name()
{
	usart_transmit_string("teamname: \"G9\"");
	check_success();
		
	_delay_ms(1000);
	
	usart_transmit_string("connect");
	check_success();
}

ISR(TIMER1_OVF_vect)
{   
	//Erwtima G
	char key_pressed = keypad_to_ascii(scan_keypad_rising_edge());
	if(key_pressed == '9')
		usart_transmit_string("ready: \"true\"");
	else
		usart_transmit_string("ready: \"false\"");
		
	check_success();
	TCNT1=0xF0BD; //timer interrupt in 0.5s
}


int main(void)
{
	DDRC = 0xF0;
	TIMSK = (1<<TOIE1);
	TCCR1B =((1<<CS12)|(0<<CS11)|(1<<CS10));
	usart_init();
	lcd_init();
	TCNT1=0xF0BD; //timer interrupt in 0.5s
	sei();
	
	while (1)
	{
		//erwtima A
		initialize_team_name();

		//erwtima B
		unsigned int temp = return_temp();
		get_digits(temp);
		usart_transmit_string("payload: [{\"name\": \"Temperature\",\"value\": ");
		cli();
		usart_transmit(res[2]+0x30);
		usart_transmit(res[1]+0x30);
		usart_transmit(res[0]+0x30);
		usart_transmit_string("}]");
		sei();
		check_success();
	}
}
