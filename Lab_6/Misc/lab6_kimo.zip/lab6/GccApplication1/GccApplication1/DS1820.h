#include <avr/io.h>
#include <util/delay.h>

unsigned char one_wire_reset(){
	unsigned char crc;
	DDRA  |=  (1 << PA4);
	PORTA &= ~(1 << PA4);
	_delay_us(480);
	// mb DDRA= (0<<PA4)
	DDRA  &= ~(1 << PA4);
	PORTA &= ~(1 << PA4);
	_delay_us(100);
	crc = PINA ;
	_delay_us(380);
	if((crc & 0x10) == 0x10){
		return 0;
	}
	else{
		return 1;
	}	
	return -1;
}

void one_wire_transmit_bit(unsigned char bit){
	DDRA  |=   (1<<PA4);
	PORTA &= ~(1<<PA4);
	_delay_us(2);
	if((bit & 0x01)==0x01){
		PORTA |= (1<<PA4);
	}
	if((bit & 0x01)==0x00){
		PORTA &= (1<<PA4);
	}
	_delay_us(58);
	DDRA  &= ~(1<<PA4);
	PORTA &= ~(1<<PA4);
	_delay_us(1);
} 

void one_wire_transmit_byte(unsigned char byte){
	unsigned char bit_to_send;
	for(int i=0; i<8; i++){
		bit_to_send = byte & 0x01;
		if(bit_to_send == 0){
		one_wire_transmit_bit(0);
		}
		else if(bit_to_send == 1){
		one_wire_transmit_bit(1);
		}
		byte = byte >> 1;
	}	
}
unsigned char one_wire_receive_bit(){
	unsigned char bit_to_return = 0;
	DDRA  |=  (1 << PA4);
	PORTA &= ~(1 << PA4);
	_delay_us(2);
	DDRA  &= ~(1 << PA4);
	PORTA &= ~(1 << PA4);
	_delay_us(10);
	if( (PINA & 0X10) == 0x10 ){
		bit_to_return = 1;
	}
	_delay_us(49);
	return bit_to_return;
}
unsigned char one_wire_receive_byte(){
	unsigned char bit_received,byte_to_return=0;
	for(int i =0 ; i<8 ; i++){
		byte_to_return = byte_to_return >> 1;
		bit_received = one_wire_receive_bit();
		if(bit_received == 1){
			bit_received = 0x80;	
		}
		byte_to_return= byte_to_return | bit_received ;
	}
	return byte_to_return;
}
unsigned int return_temp(){
	unsigned char crc,finished,temp,temp_sign;
	int sign;
	crc = one_wire_reset();
    if(crc == 0x00){
	   return 0x8000;
	}
	one_wire_transmit_byte(0xCC);
	one_wire_transmit_byte(0x44);
	while(1){
		finished = one_wire_receive_bit();
		if((finished & 0x01) == 0x01){
			break;
		}
	}
	crc = one_wire_reset();
	if(crc == 0x00){
		return 0x8000;
	}
	one_wire_transmit_byte(0xCC);
	one_wire_transmit_byte(0xBE);
	temp = one_wire_receive_byte();
	temp = temp >> 1 ;
	temp_sign = one_wire_receive_byte();
	sign =  temp_sign;
	sign = sign <<  8;
	sign = sign & 0xFF00;
	return  (sign | temp);
	
		
}